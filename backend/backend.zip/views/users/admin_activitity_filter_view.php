           <div class="panel-body profile-activity">
                             <table class="table table-hover file-search">
                          <thead>
                          <tr>
                              <th>File Name &amp; Location</th>
                              <th class="hidden-phone">Created</th>
                              <th class="hidden-phone">Last Modify</th>
                              <th>Size</th>
                              <th class="hidden-phone">Type</th>
                          </tr>
                          </thead>
                          <tbody>
                          <tr>
                              <td>
                                  <img alt="" src="img/file-search/doc.png">
                                  <strong>Linux Manual for dummies.doc</strong>
                                  <span>C:\Users\Murat\Documents\My Dropbox</span>
                              </td>
                              <td class="hidden-phone">01.01.2012	</td>
                              <td class="hidden-phone">12.05.2013</td>
                              <td>193 KB</td>
                              <td class="hidden-phone">File</td>
                          </tr>
                          <tr>
                              <td>
                                  <img alt="" src="img/file-search/ppt.png">
                                  <strong>User Documentation.ppt</strong>
                                  <span>C:\Users\Murat\Documents\My Dropbox</span>
                              </td>
                              <td class="hidden-phone">01.01.2012	</td>
                              <td class="hidden-phone">12.05.2013</td>
                              <td>193 KB</td>
                              <td class="hidden-phone">File</td>
                          </tr>
                          <tr>
                              <td>
                                  <img alt="" src="img/file-search/xls.png">
                                  <strong>Price chart Table.xls</strong>
                                  <span>C:\Users\Murat\Documents\My Dropbox</span>
                              </td>
                              <td class="hidden-phone">01.01.2012	</td>
                              <td class="hidden-phone">12.05.2013</td>
                              <td>193 KB</td>
                              <td class="hidden-phone">File</td>
                          </tr>
                          <tr>
                              <td>
                                  <img alt="" src="img/file-search/jpg.png">
                                  <strong>Linux Wallpaper.jpg</strong>
                                  <span>C:\Users\Murat\Documents\My Dropbox</span>
                              </td>
                              <td class="hidden-phone">01.01.2012	</td>
                              <td class="hidden-phone">12.05.2013</td>
                              <td>193 KB</td>
                              <td class="hidden-phone">File</td>
                          </tr>
                          <tr>
                              <td>
                                  <img alt="" src="img/file-search/zip.png">
                                  <strong>All Main files.zip</strong>
                                  <span>C:\Users\Murat\Documents\My Dropbox</span>
                              </td>
                              <td class="hidden-phone">01.01.2012	</td>
                              <td class="hidden-phone">12.05.2013</td>
                              <td>193 KB</td>
                              <td class="hidden-phone">File</td>
                          </tr>
                          <tr>
                              <td>
                                  <img alt="" src="img/file-search/pdf.png">
                                  <strong>Metro Lab User Manual and Help fiule.pdf</strong>
                                  <span>C:\Users\Murat\Documents\My Dropbox</span>
                              </td>
                              <td class="hidden-phone">01.01.2012	</td>
                              <td class="hidden-phone">12.05.2013</td>
                              <td>193 KB</td>
                              <td class="hidden-phone">File</td>
                          </tr>
                          <tr>
                              <td>
                                  <img alt="" src="img/file-search/ai.png">
                                  <strong>Vector Lab Logo and Other stuff.ai</strong>
                                  <span>C:\Users\Murat\Documents\My Dropbox</span>
                              </td>
                              <td class="hidden-phone">01.01.2012	</td>
                              <td class="hidden-phone">12.05.2013</td>
                              <td>193 KB</td>
                              <td class="hidden-phone">File</td>
                          </tr>
                          <tr>
                              <td>
                                  <img alt="" src="img/file-search/psd.png">
                                  <strong>Vectorlab wallpaper.psd</strong>
                                  <span>C:\Users\Murat\Documents\My Dropbox</span>
                              </td>
                              <td class="hidden-phone">01.01.2012	</td>
                              <td class="hidden-phone">12.05.2013</td>
                              <td>193 KB</td>
                              <td class="hidden-phone">File</td>
                          </tr>
                          <tr>
                              <td>
                                  <img alt="" src="img/file-search/rss.png">
                                  <strong>themeforest feed.rss</strong>
                                  <span>C:\Users\Murat\Documents\My Dropbox</span>
                              </td>
                              <td class="hidden-phone">01.01.2012	</td>
                              <td class="hidden-phone">12.05.2013</td>
                              <td>193 KB</td>
                              <td class="hidden-phone">File</td>
                          </tr>
                          <tr>
                              <td>
                                  <img alt="" src="img/file-search/email.png">
                                  <strong>Order and Contact.eml</strong>
                                  <span>C:\Users\Murat\Documents\My Dropbox</span>
                              </td>
                              <td class="hidden-phone">01.01.2012	</td>
                              <td class="hidden-phone">12.05.2013</td>
                              <td>193 KB</td>
                              <td class="hidden-phone">File</td>
                          </tr>
                          <tr>
                              <td>
                                  <img alt="" src="img/file-search/eps.png">
                                  <strong>Metro Lab.eps</strong>
                                  <span>C:\Users\Murat\Documents\My Dropbox</span>
                              </td>
                              <td class="hidden-phone">01.01.2012	</td>
                              <td class="hidden-phone">12.05.2013</td>
                              <td>193 KB</td>
                              <td class="hidden-phone">File</td>
                          </tr>

                          </tbody>
                      </table>

                      <div class="text-center">
                          <ul class="pagination">
                              <li><a href="#">«</a></li>
                              <li><a href="#">1</a></li>
                              <li><a href="#">2</a></li>
                              <li><a href="#">3</a></li>
                              <li><a href="#">4</a></li>
                              <li><a href="#">5</a></li>
                              <li><a href="#">»</a></li>
                          </ul>
                      </div>
                          </div>
